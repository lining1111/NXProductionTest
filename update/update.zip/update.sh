#!/bin/bash

echo "你好"

echo "1">log
